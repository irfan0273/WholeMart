import React from 'react'

const MyOrder = () => {
  return (
    <div>
      MY Order
    </div>
  )
}

export default MyOrder
