import React from 'react'

function SearchPage() {
  return (
    <div>
      Hello
    </div>
  )
}

export default SearchPage
